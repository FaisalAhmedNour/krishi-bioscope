export default function NotFound() {
    return (
        <div className="text-center">The Reqested resource was not found.</div>
    )
}