export function GET(req: any){
    return Response.json({msg: 'its working'})
}

export function POST(req: any){
    return Response.json({msg: 'its working'})
}

export function PUT(req: any){
    return Response.json({msg: 'its working'})
}

export function DELETE(req: any){
    return Response.json({msg: 'its working'})
}
